const express = require('express');
const session = require('express-session');
const app = express();
const port = 3000;

// Store user info with session ID
let userSessions = {};

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: true
}));
app.set('view engine', 'ejs');

// Routes
app.get('/', (req, res) => {
    res.render('login', { loggedInUser: '' });
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;

    if (username === password) {
        req.session.loggedInUser = username;
        userSessions[req.sessionID] = username; // Store username with session ID
        res.redirect('/welcome');
    } else {
        res.render('unauth', { userSessions: Object.entries(userSessions) });
    }
});

app.get('/welcome', (req, res) => {
    const loggedInUser = req.session.loggedInUser;
    if (loggedInUser) {
        res.render('welcome', { username: loggedInUser });
    } else {
        res.redirect('/');
    }
});

app.get('/logout', (req, res) => {
    delete userSessions[req.sessionID]; // Remove user info when logging out
    req.session.destroy((err) => {
        if (err) {
            console.log(err);
        } else {
            res.redirect('/');
        }
    });
});

// Server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
