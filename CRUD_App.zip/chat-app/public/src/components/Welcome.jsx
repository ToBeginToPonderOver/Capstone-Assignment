import React, { useState, useEffect } from "react"; // Importing React, useState, and useEffect from the 'react' package
import styled from "styled-components"; // Importing the 'styled' function from the 'styled-components' package
import Robot from "../assets/robot.gif"; // Importing the 'robot.gif' image from the '../assets' directory

export default function Welcome() { // Defining a functional component called 'Welcome'
  const [userName, setUserName] = useState(""); // Declaring a state variable called 'userName' and a function to update it called 'setUserName', initializing it with an empty string
  useEffect(async () => { // Using the 'useEffect' hook to perform a side effect (asynchronous operation) after the component has rendered
    setUserName( // Updating the 'userName' state variable
      await JSON.parse( // Parsing the JSON data retrieved from local storage
        localStorage.getItem(process.env.REACT_APP_LOCALHOST_KEY) // Retrieving the value associated with the key 'REACT_APP_LOCALHOST_KEY' from local storage
      ).username // Accessing the 'username' property of the parsed JSON data
    );
  }, []); // The empty dependency array ensures that the effect runs only once, after the initial render

  return (
    <Container> // Rendering a 'Container' component
      <img src={Robot} alt="" /> {/* Rendering an image with the 'Robot' source and an empty alt text */}
      <h1>
        Welcome, <span>{userName}!</span> {/* Rendering a welcome message with the value of 'userName' wrapped in a 'span' element */}
      </h1>
      <h3>Please select a chat to Start messaging.</h3> {/* Rendering a message prompting the user to select a chat */}
    </Container>
  );
}

const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  flex-direction: column;
  img {
    height: 20rem;
  }
  span {
    color: #4e0eff;
  }
`;
