import React from "react";
import { useNavigate } from "react-router-dom";
import { BiPowerOff } from "react-icons/bi";
import styled from "styled-components";
import axios from "axios";
import { logoutRoute } from "../utils/APIRoutes";

// This component represents a logout button
export default function Logout() {
  const navigate = useNavigate();

  // This function is called when the logout button is clicked
  const handleClick = async () => {
    // Retrieve the user ID from local storage
    const id = await JSON.parse(
      localStorage.getItem(process.env.REACT_APP_LOCALHOST_KEY)
    )._id;

    // Send a GET request to the logout route with the user ID
    const data = await axios.get(`${logoutRoute}/${id}`);

    // If the request is successful (status code 200), perform logout actions
    if (data.status === 200) {
      // Clear the local storage
      localStorage.clear();

      // Navigate to the login page
      navigate("/login");
    }
  };

  return (
    // Render a button with a logout icon
    <Button onClick={handleClick}>
      <BiPowerOff />
    </Button>
  );
}

// Styled component for the logout button
const Button = styled.button`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0.5rem;
  border-radius: 0.5rem;
  background-color: #9a86f3;
  border: none;
  cursor: pointer;

  // Styling for the logout icon
  svg {
    font-size: 1.3rem;
    color: #ebe7ff;
  }
`;