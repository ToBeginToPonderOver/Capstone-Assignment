// This file, APIRoutes.js, contains the definition of several API routes used in a web application.

// The 'host' variable stores the base URL of the API server.
export const host = "http://localhost:4000";

// The 'loginRoute' variable stores the complete URL for the login route.
export const loginRoute = `${host}/api/auth/login`;

// The 'registerRoute' variable stores the complete URL for the register route.
export const registerRoute = `${host}/api/auth/register`;

// The 'logoutRoute' variable stores the complete URL for the logout route.
export const logoutRoute = `${host}/api/auth/logout`;

// The 'allUsersRoute' variable stores the complete URL for the route to fetch all users.
export const allUsersRoute = `${host}/api/auth/allusers`;

// The 'sendMessageRoute' variable stores the complete URL for the route to send a message.
export const sendMessageRoute = `${host}/api/messages/addmsg`;

// The 'recieveMessageRoute' variable stores the complete URL for the route to receive messages.
export const recieveMessageRoute = `${host}/api/messages/getmsg`;

// The 'setAvatarRoute' variable stores the complete URL for the route to set user avatar.
export const setAvatarRoute = `${host}/api/auth/setavatar`;