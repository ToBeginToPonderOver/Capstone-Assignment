const mongoose = require("mongoose"); // Importing the mongoose library

const MessageSchema = mongoose.Schema( // Defining a new mongoose schema for the Message model
  {
    message: {
      text: { type: String, required: true }, // Defining a nested field 'text' of type String which is required
    },
    users: Array, // Defining a field 'users' of type Array
    sender: {
      type: mongoose.Schema.Types.ObjectId, // Defining a field 'sender' of type ObjectId
      ref: "User", // Referencing the "User" model
      required: true, // The 'sender' field is required
    },
  },
  {
    timestamps: true, // Adding timestamps to the schema (createdAt and updatedAt fields)
  }
);

module.exports = mongoose.model("Messages", MessageSchema); // Exporting the Message model with the defined schema