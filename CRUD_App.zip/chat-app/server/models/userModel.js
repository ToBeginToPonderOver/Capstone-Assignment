// Import the mongoose library
const mongoose = require("mongoose");

// Define a new mongoose schema for the user model
const userSchema = new mongoose.Schema({
  // Define the username field with the following properties:
  username: {
    type: String, // The data type is a string
    required: true, // The field is required
    min: 3, // The minimum length of the string is 3 characters
    max: 20, // The maximum length of the string is 20 characters
    unique: true, // The value of this field must be unique
  },
  // Define the email field with the following properties:
  email: {
    type: String, // The data type is a string
    required: true, // The field is required
    unique: true, // The value of this field must be unique
    max: 50, // The maximum length of the string is 50 characters
  },
  // Define the password field with the following properties:
  password: {
    type: String, // The data type is a string
    required: true, // The field is required
    min: 8, // The minimum length of the string is 8 characters
  },
  // Define the isAvatarImageSet field with the following properties:
  isAvatarImageSet: {
    type: Boolean, // The data type is a boolean
    default: false, // The default value is false
  },
  // Define the avatarImage field with the following properties:
  avatarImage: {
    type: String, // The data type is a string
    default: "", // The default value is an
  },
});

module.exports = mongoose.model("Users", userSchema);
