// Import the addMessage and getMessages functions from the messageController module
const { addMessage, getMessages } = require("../controllers/messageController");

// Import the express module and create a router object
const router = require("express").Router();

// Define a route for adding a message
router.post("/addmsg/", addMessage);

// Define a route for getting messages
router.post("/getmsg/", getMessages);

// Export the router object to be used in other files
module.exports = router;