// Import the necessary functions from the userController module
const {
  login,
  register,
  getAllUsers,
  setAvatar,
  logOut,
} = require("../controllers/userController");

// Import the express module and create a router object
const router = require("express").Router();

// Define the routes and their corresponding handler functions
router.post("/login", login); // POST request to /login route will be handled by the login function
router.post("/register", register); // POST request to /register route will be handled by the register function
router.get("/allusers/:id", getAllUsers); // GET request to /allusers/:id route will be handled by the getAllUsers function
router.post("/setavatar/:id", setAvatar); // POST request to /setavatar/:id route will be handled by the setAvatar function
router.get("/logout/:id", logOut); // GET request to /logout/:id route will be handled by the logOut function

// Export the router object to be used in other parts of the application
module.exports = router;