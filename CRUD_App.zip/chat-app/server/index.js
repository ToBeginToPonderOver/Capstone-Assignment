// Importing required modules
const express = require("express"); // Express framework for building web applications
const cors = require("cors"); // CORS middleware for handling cross-origin requests
const mongoose = require("mongoose"); // Mongoose library for MongoDB object modeling
const authRoutes = require("./routes/auth"); // Importing authentication routes
const messageRoutes = require("./routes/messages"); // Importing message routes

// Creating an instance of the Express application
const app = express();

// Importing the socket.io library
const socket = require("socket.io");

// Loading environment variables from a .env file
require("dotenv").config();

// Middleware for enabling CORS
app.use(cors());

// Middleware for parsing JSON data in the request body
app.use(express.json());

// Connecting to the MongoDB database using Mongoose
mongoose
  .connect(process.env.MONGO_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("DB Connection Successful");
  })
  .catch((err) => {
    console.log(err.message);
  });

// Mounting the authentication routes on the "/api/auth" path
app.use("/api/auth", authRoutes);

// Mounting the message routes on the "/api/messages" path
app.use("/api/messages", messageRoutes);

// Starting the server and listening on the specified port from the environment variables
const server = app.listen(process.env.PORT, () =>
  console.log(`Server started on ${process.env.PORT}`)
);

// Creating a socket.io instance and configuring it with CORS settings
const io = socket(server, {
  cors: {
    origin: "http://localhost:3000", // Allowing requests from the specified origin
    credentials: true, // Allowing credentials to be sent with the requests
  },
});

// Creating a global map to store online users and their corresponding socket IDs
global.onlineUsers = new Map();

// Handling socket.io connections
io.on("connection", (socket) => {
  global.chatSocket = socket;

  // Event handler for adding a user to the online users map
  socket.on("add-user", (userId) => {
    onlineUsers.set(userId, socket.id);
  });

  // Event handler for sending a message
  socket.on("send-msg", (data) => {
    const sendUserSocket = onlineUsers.get(data.to);
    if (sendUserSocket) {
      // Emitting the "msg-recieve" event to the recipient socket
      socket.to(sendUserSocket).emit("msg-recieve", data.msg);
    }
  });
});