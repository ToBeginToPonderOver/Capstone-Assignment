const Messages = require("../models/messageModel");

// Get messages between two users
module.exports.getMessages = async (req, res, next) => {
  try {
    const { from, to } = req.body;

    // Find messages where both users are involved
    const messages = await Messages.find({
      users: {
        $all: [from, to],
      },
    }).sort({ updatedAt: 1 });

    // Project the messages to include only necessary information
    const projectedMessages = messages.map((msg) => {
      return {
        fromSelf: msg.sender.toString() === from,
        message: msg.message.text,
      };
    });

    // Send the projected messages as a JSON response
    res.json(projectedMessages);
  } catch (ex) {
    next(ex);
  }
};

// Add a new message
module.exports.addMessage = async (req, res, next) => {
  try {
    const { from, to, message } = req.body;

    // Create a new message document in the database
    const data = await Messages.create({
      message: { text: message },
      users: [from, to],
      sender: from,
    });

    // Check if the message was successfully added to the database
    if (data) return res.json({ msg: "Message added successfully." });
    else return res.json({ msg: "Failed to add message to the database" });
  } catch (ex) {
    next(ex);
  }
};