const User = require("../models/userModel"); // Importing the User model from the userModel file
const bcrypt = require("bcrypt"); // Importing the bcrypt library for password hashing

module.exports.login = async (req, res, next) => {
  try {
    const { username, password } = req.body; // Extracting the username and password from the request body
    const user = await User.findOne({ username }); // Finding a user with the provided username
    if (!user)
      return res.json({ msg: "Incorrect Username or Password", status: false }); // If no user is found, return an error message
    const isPasswordValid = await bcrypt.compare(password, user.password); // Comparing the provided password with the hashed password stored in the user object
    if (!isPasswordValid)
      return res.json({ msg: "Incorrect Username or Password", status: false }); // If the password is invalid, return an error message
    delete user.password; // Removing the password field from the user object
    return res.json({ status: true, user }); // Return a success message along with the user object
  } catch (ex) {
    next(ex); // If an exception occurs, pass it to the error handling middleware
  }
};

module.exports.register = async (req, res, next) => {
  try {
    const { username, email, password } = req.body; // Extracting the username, email, and password from the request body
    const usernameCheck = await User.findOne({ username }); // Checking if the provided username is already taken
    if (usernameCheck)
      return res.json({ msg: "Username already used", status: false }); // If the username is already taken, return an error message
    const emailCheck = await User.findOne({ email }); // Checking if the provided email is already used
    if (emailCheck)
      return res.json({ msg: "Email already used", status: false }); // If the email is already used, return an error message
    const hashedPassword = await bcrypt.hash(password, 10); // Hashing the provided password
    const user = await User.create({
      email,
      username,
      password: hashedPassword,
    }); // Creating a new user with the provided email, username, and hashed password
    delete user.password; // Removing the password field from the user object
    return res.json({ status: true, user }); // Return a success message along with the user object
  } catch (ex) {
    next(ex); // If an exception occurs, pass it to the error handling middleware
  }
};

module.exports.getAllUsers = async (req, res, next) => {
  try {
    const users = await User.find({ _id: { $ne: req.params.id } }).select([
      "email",
      "username",
      "avatarImage",
      "_id",
    ]); // Finding all users except the one with the provided id and selecting only specific fields
    return res.json(users); // Return the list of users
  } catch (ex) {
    next(ex); // If an exception occurs, pass it to the error handling middleware
  }
};

module.exports.setAvatar = async (req, res, next) => {
  try {
    const userId = req.params.id; // Extracting the user id from the request parameters
    const avatarImage = req.body.image; // Extracting the avatar image from the request body
    const userData = await User.findByIdAndUpdate(
      userId,
      {
        isAvatarImageSet: true,
        avatarImage,
      },
      { new: true }
    ); // Updating the user's avatar image and setting the isAvatarImageSet flag to true
    return res.json({
      isSet: userData.isAvatarImageSet,
      image: userData.avatarImage,
    }); // Return the updated avatar image information
  } catch (ex) {
    next(ex); // If an exception occurs, pass it to the error handling middleware
  }
};

module.exports.logOut = (req, res, next) => {
  try {
    if (!req.params.id) return res.json({ msg: "User id is required " }); // If the user id is not provided, return an error message
    onlineUsers.delete(req.params.id); // Remove the user from the onlineUsers collection
    return res.status(200).send(); // Return a success status code
  } catch (ex) {
    next(ex); // If an exception occurs, pass it to the error handling middleware
  }
};