// server.js

const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());

app.get('/', (req, res) => {
  res.render('index');
});

app.post('/set-cookie', (req, res) => {
  const { name, age } = req.body;
  res.cookie('userName', name, { maxAge: 900000 }); // setting cookie for 15 minutes
  res.cookie('userAge', age, { maxAge: 900000 });
  res.send('Cookies set successfully');
});

app.get('/display-cookies', (req, res) => {
  const { userName, userAge } = req.cookies;
  res.render('cookies', { userName, userAge });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
