// var, let and const

var num = 33;
console.log(num); // 33

let no = 22;
console.log(no); // 22

const pi = 3.14;
console.log(pi); // 3.14


// use strict 
"use strict";
x = 10; // Throws an error because x is not declared


// Destructuring
const [a, b] = [1, 2];
console.log(a, b); // 1 2


// Spread Operator
let arr = [1, 2, 3];
let arr2 = [...arr, 4, 5];
console.log(arr2); // [1, 2, 3, 4, 5]

// Spread with Destructuring
let arr3 = [1, 2, 3];
let [x, y, ...z] = arr3;
console.log(x, y, z); // 1 2 [3]

// map
const map = new Map();
map.set('name', 'John');
map.set('age', 30);
console.log(map.get('name')); // John

// Weak map
const weakMap = new WeakMap();
let obj = {};
weakMap.set(obj, 'John');
console.log(weakMap.get(obj)); // John


// Set
const set = new Set([1, 2, 3, 4, 5]);
console.log(set.has(1)); // true

// Weak Set
const weakSet = new WeakSet();
let obj = {msg: 'Hello'};
weakSet.add(obj);
console.log(weakSet.has(obj)); // true

// Classes
class Person {
    constructor(name) {
        this.name = name;
    }
    sayName() {
        console.log(`My name is ${this.name}`);
    }
}

let person = new Person('John');
person.sayName(); // My name is John

// Iterators
let arr = [1, 2, 3];
let iter = arr[Symbol.iterator]();
console.log(iter.next().value); // 1

// Generators
function* generator() {
    yield 1;
    yield 2;
    yield 3;
}
const gen = generator();
console.log(gen.next());

// Promises
let promise = new Promise((resolve, reject) => {
    let sum = 1 + 2;
    if (sum === 2) {
        resolve('Success');
    } else {
        reject('Error');
    }
}); // A Big ERROR

// proxy
let handler = {
    get: function(target, name) {
        return name in target ? target[name] : 42;
    }
};
let p = new Proxy({}, handler);
p.a = 1;
p.b = undefined;
console.log(p.a, p.b); // 1 undefined
console.log('c' in p, p.c); // false 42

// callback
function greet(name, callback) {
    console.log('Hello ' + name);
    callback();
}
greet('John', function() {
    console.log('The callback is invoked');
}); // Hello John The callback is invoked

// async/await
async function greet() {
    return 'Hello';
}
greet().then(value => console.log(value)); // Hello

// arrow function
let greet = (name) => {
    console.log('Hello ' + name);
}
greet('John'); // Hello John

// hoisting
console.log(x); // undefined
var x = 5;

// closure
function outer() {
    let name = 'John';
    function inner() {
        console.log(name);
    }
    return inner;
}
let result = outer();
result(); // John

// function scoping
function greet() {
    let name = 'John';
    console.log('Hello ' + name);
}
greet(); // Hello John
